package cl.duoc.ppizza;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Carrito extends AppCompatActivity {

//    public Carrito() {
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);

        ArrayList<Pedido> lista = new ArrayList<>();

        //ListView lvListarCarrito = findViewById(R.id.lvCarrito);

        //declarar y asignar NOMBRE
        String nombrePizza = getIntent().getStringExtra("nombre");
        int cantidadPizza = getIntent().getIntExtra("cantidad",0);
        int totalPizza = getIntent().getIntExtra("total",0);

        Pedido ped = new Pedido(nombrePizza,cantidadPizza,totalPizza);
        lista.add(ped);

        AdaptadorCarrito carAdaptador = new AdaptadorCarrito(Carrito.this, R.layout.plantillacarrito, lista);
        ListView lvCarrito = findViewById(R.id.lvCarrito);
        lvCarrito.setAdapter(carAdaptador);



    }
}

class AdaptadorCarrito extends ArrayAdapter<Pedido>{
    private Context carContexto;
    private int carRecurso;
    private ArrayList<Pedido> carMiLista;

    public AdaptadorCarrito (Context carContexto, int carRecurso, ArrayList<Pedido> carMiLista){
        super(carContexto,carRecurso,carMiLista);
        this.carContexto=carContexto;
        this.carRecurso=carRecurso;
        this.carMiLista=carMiLista;


    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);
        View view = LayoutInflater.from(carContexto).inflate(carRecurso, null);

        TextView carCantidad = view.findViewById(R.id.carCantidad);
        TextView carNombre = view.findViewById(R.id.carNombre);
        TextView carTotal = view.findViewById(R.id.carTotal);
        ImageButton carEliminar = view.findViewById(R.id.carEliminar);

        Pedido pp = carMiLista.get(position);
        carNombre.setText(String.valueOf(pp.getNombre()));
        carCantidad.setText(String.valueOf(pp.getCantidad()));
        carTotal.setText(String.valueOf(pp.getTotal()));

        carEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Elimina item de listView
                carMiLista.remove(position);
                //Refresca la pantalla
                notifyDataSetChanged();

                //Muestra mensaje toast que se eliminado el item
                Toast.makeText(carContexto,"Registro Eliminado",Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
