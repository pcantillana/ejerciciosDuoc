package cl.duoc.ppizza;

public class Pedido {
    private String nombre;
    private int cantidad;
    private int total;

    public Pedido(){
        nombre ="";
        cantidad =0;
        total =0;
    }
    public Pedido(String nombre, int cantidad, int total) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.total = total;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "nombre='" + nombre + '\'' +
                ", cantidad=" + cantidad +
                ", total=" + total +
                '}';
    }


}
