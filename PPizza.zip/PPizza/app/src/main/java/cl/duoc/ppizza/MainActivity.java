package cl.duoc.ppizza;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView lvListar = findViewById(R.id.lvLista);

        lvListar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Pizzas piz = (Pizzas) lvListar.getItemAtPosition(position);
                Intent intento = new Intent(MainActivity.this,Cantidades.class);
                intento.putExtra("nombre",piz.getNombre());
                intento.putExtra("descripcion",piz.getDescripcion());
                intento.putExtra("precio",piz.getPrecio());
                intento.putExtra("imagen",piz.getImagen());
                startActivity(intento);
                //Toast.makeText(getApplicationContext(),piz.getNombre(),Toast.LENGTH_SHORT).show();
            }
        });

        //se crea objeto arraylist
        ArrayList<Pizzas> lista = new ArrayList<>();
        Pizzas p1 = new Pizzas("Pizza Napolitana", "Queso, Champiñon, Aceitunas", 1000,R.drawable.pizza1,0);
        Pizzas p2 = new Pizzas("Pizza Mediterranea", "Queso, Salame, Aceitunas", 2000,R.drawable.pizza2,0);
        Pizzas p3 = new Pizzas("Pizza Chilena", "Queso, Tocino, Aceitunas", 3000,R.drawable.pizza3,0);

        lista.add(p1);
        lista.add(p2);
        lista.add(p3);

        //List view personalizado
        CustomArrayAdapter adaptador = new CustomArrayAdapter(MainActivity.this,R.layout.item_pizza,lista);
        lvListar.setAdapter(adaptador);
    }
}

class CustomArrayAdapter extends ArrayAdapter<Pizzas>
{
    private Context miContexto;
    private int miRecurso;
    private ArrayList<Pizzas> miLista;

    public CustomArrayAdapter(MainActivity miContexto, int miRecurso, ArrayList<Pizzas> miLista) {
        super(miContexto, miRecurso, miLista);
        this.miContexto = miContexto;
        this.miRecurso = miRecurso;
        this.miLista = miLista;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = LayoutInflater.from(getContext()).inflate(miRecurso, null);
        TextView lblnombre = view.findViewById(R.id.lblnombre);
        TextView lbldescripcion = view.findViewById(R.id.lbldescripcion);
        TextView lblprecio = view.findViewById(R.id.lblprecio);
        ImageView imagen = view.findViewById(R.id.imgView);

        Pizzas p = miLista.get(position);

        lblnombre.setText(String.valueOf(p.getNombre()));
        lbldescripcion.setText(String.valueOf(p.getDescripcion()));
        lblprecio.setText(String.valueOf(p.getPrecio()));
        imagen.setImageResource(p.getImagen());

        return view;
    }
}