package cl.duoc.ppizza;

public class Pizzas {

    private String nombre;
    private String descripcion;
    private int precio;
    private int imagen;
    private int cantidad;

    public Pizzas() {
        nombre ="";
        descripcion ="";
        precio =0;
        imagen =0;
        cantidad=0;
    }

    public Pizzas(String nombre, String descripcion, int precio, int imagen, int cantidad) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Pizzas{" +
                "nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", precio=" + precio +
                ", imagen=" + imagen +
                ", cantidad=" + cantidad +
                '}';
    }

    //Metodo aumentar
    public int aumDis(int totalAcumulador, boolean modo){
        int acumulador = totalAcumulador;

        if(modo){

            acumulador++;
        }else{
            acumulador--;
        }

        return acumulador;
    }
}
