package cl.duoc.ppizza;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Cantidades extends AppCompatActivity {
    public int acumulador =1;
    public int totalCalcular =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cantidades);
        Pizzas c = new Pizzas();


        //declarar y asignar NOMBRE
        String nombrePizza = getIntent().getStringExtra("nombre");
        String descripcionPizza = getIntent().getStringExtra("descripcion");
        int precioPizza = getIntent().getIntExtra("precio",0);
        int imagenPizza = getIntent().getIntExtra("imagen",0);
        ImageButton ibCantidadDis = findViewById(R.id.cantdisminuir);
        ImageButton ibCantidadAum = findViewById(R.id.cantaumentar);
        TextView tvCantidad = findViewById(R.id.cantcantidad);
        TextView tvTotal = findViewById(R.id.canttotal);
        Button btnCarrito = findViewById(R.id.cantCarrito);

        //Inicializar Contador
        tvCantidad.setText(String.valueOf(acumulador));

        //Inicializar total
        tvTotal.setText(String.valueOf(precioPizza * acumulador));

        ibCantidadDis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // se hace el calculo
                totalCalcular = (precioPizza * (acumulador-1));
                //tomamos el nuevo valor del acumulador
                acumulador = c.aumDis(acumulador, false);
                //convertir el acumulador int a string
                tvCantidad.setText(String.valueOf(acumulador));
                //pasar el valor string al tvtotal o textview
                tvTotal.setText(String.valueOf(totalCalcular));

            }
        });


        ibCantidadAum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                totalCalcular = (precioPizza * (acumulador+1));
                //tomamos el nuevo valor del acumulador
                acumulador = c.aumDis(acumulador, true);

                //convertir el acumulador int a string
                tvCantidad.setText(String.valueOf(acumulador));

                //pasar el valor string al tvtotal o textview
                tvTotal.setText(String.valueOf(totalCalcular));
            }
        });

        //Se agrega producto a carrito
        btnCarrito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(Cantidades.this,Carrito.class);

                intento.putExtra("nombre",nombrePizza);
                intento.putExtra("precio",precioPizza);
                intento.putExtra("total",totalCalcular);
                startActivity(intento);
            }
        });

        //muestra nombre
        TextView tvNombre = findViewById(R.id.cantNombre);
        tvNombre.setText(nombrePizza);

        //muestra Descripcion
        TextView tvDescripcion = findViewById(R.id.cantDescripcion);
        tvDescripcion.setText(String.valueOf(descripcionPizza));

        //muestra Precio
        TextView tvPrecio = findViewById(R.id.cantprecio);
        tvPrecio.setText(String.valueOf(precioPizza));

        //Muestra Imagen
        ImageView ivCantidad = findViewById(R.id.ivcantidad);
        ivCantidad.setImageResource(imagenPizza);



    }
}