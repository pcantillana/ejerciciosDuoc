package cl.duoc.ppizza;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Cantidades extends AppCompatActivity {
    public int acumulador =1;
    public int totalCalcular =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cantidades);
        Pizzas c = new Pizzas();
        ArrayList<Pizzas> lista = new ArrayList<>();


        //declarar y asignar NOMBRE
        String nombrePizza = getIntent().getStringExtra("nombre");
        String descripcionPizza = getIntent().getStringExtra("descripcion");
        int precioPizza = getIntent().getIntExtra("precio",0);
        int imagenPizza = getIntent().getIntExtra("imagen",0);
        ImageButton ibCantidadDis = findViewById(R.id.cantdisminuir);
        ImageButton ibCantidadAum = findViewById(R.id.cantaumentar);
        TextView tvCantidad = findViewById(R.id.cantcantidad);
        TextView tvTotal = findViewById(R.id.canttotal);
        Button btnCarrito = findViewById(R.id.cantCarrito);

        //Inicializar Contador
        tvCantidad.setText(String.valueOf(acumulador));

        //Inicializar total
        tvTotal.setText(String.valueOf(precioPizza * acumulador));

        ibCantidadDis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // se hace el calculo
                totalCalcular = (precioPizza * (acumulador-1));
                //tomamos el nuevo valor del acumulador
                acumulador = c.aumDis(acumulador, false);
                //convertir el acumulador int a string
                tvCantidad.setText(String.valueOf(acumulador));
                //pasar el valor string al tvtotal o textview
                tvTotal.setText(String.valueOf(totalCalcular));

            }
        });


        ibCantidadAum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                totalCalcular = (precioPizza * (acumulador+1));
                //tomamos el nuevo valor del acumulador
                acumulador = c.aumDis(acumulador, true);

                //convertir el acumulador int a string
                tvCantidad.setText(String.valueOf(acumulador));

                //pasar el valor string al tvtotal o textview
                tvTotal.setText(String.valueOf(totalCalcular));
            }
        });

        //Se agrega producto a carrito
        btnCarrito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(Cantidades.this,Carrito.class);

                Pizzas carritoPizzas = new Pizzas(nombrePizza,null,0,0,acumulador);
                lista.add(carritoPizzas);

                intento.putExtra("nombre",nombrePizza);
                intento.putExtra("cantidad",acumulador);
                intento.putExtra("total",totalCalcular);

                ListView lvListarCarrito = findViewById(R.id.lvCarrito);
                //se crea objeto arraylist

                /*Pizzas p1 = new Pizzas(nombrePizza, null, precioPizza,0,0);
                Pizzas p2 = new Pizzas("Pizza Mediterranea", "Queso, Salame, Aceitunas", 2000,R.drawable.pizza2,0);
                Pizzas p3 = new Pizzas("Pizza Chilena", "Queso, Tocino, Aceitunas", 3000,R.drawable.pizza3,0);

                lista.add(p1);
                lista.add(p2);
                lista.add(p3);*/



                startActivity(intento);
            }
        });

        //muestra nombre
        TextView tvNombre = findViewById(R.id.cantNombre);
        tvNombre.setText(nombrePizza);

        //muestra Descripcion
        TextView tvDescripcion = findViewById(R.id.cantDescripcion);
        tvDescripcion.setText(String.valueOf(descripcionPizza));

        //muestra Precio
        TextView tvPrecio = findViewById(R.id.cantprecio);
        tvPrecio.setText(String.valueOf(precioPizza));

        //Muestra Imagen
        ImageView ivCantidad = findViewById(R.id.ivcantidad);
        ivCantidad.setImageResource(imagenPizza);



    }
}

