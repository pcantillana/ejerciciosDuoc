package cl.duoc.registroasistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;
import java.util.ArrayList;


    public class CustomSQL extends SQLiteOpenHelper {

        private Context miContexto;
        private String BD;
        private SQLiteDatabase.CursorFactory factory;
        private int version;


        //Constructor BD con parametros


        public CustomSQL(@Nullable Context context, @Nullable String BD, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
            super(context, BD, factory, version);
            this.miContexto = miContexto;
            this.BD = BD;
            this.version = version;
            this.factory = factory;
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            //String query = "create table lista(id integer primary key autoincrement, run integer, dv text, nombre text, fecha text)";

            String query = "create table lista(id integer primary key autoincrement, run integer, dv text, nombre text, fecha text)";
            db.execSQL(query);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }

        //CRUD Create Read Update Delete

        public boolean insertar(Lista lista)
        {
            //escribir
            SQLiteDatabase escritor = this.getWritableDatabase();
            //los parametros, lo que quiero insertar
            ContentValues cv = new ContentValues();




            //cv.put("id",lista.getId());// el id se genera solo, no es necesario agregar
            cv.put("run",lista.getRun());
            cv.put("dv",lista.getDv());
            cv.put("nombre",lista.getNombre());
            cv.put("fecha",lista.getFechaIngreso());
            //cv.put("id",lista.getId());// el id se genera solo, no es necesario agregar
           /* cv.put("id",100);
            cv.put("run",123123);
            cv.put("dv","s");
            cv.put("nombre","test");
            cv.put("fecha","23-32-2021");*/



            long respuesta = escritor.insert("lista",null,cv); // insert into lista(mensaje) values(lista.getMensaje());
            escritor.close();


            return respuesta != -1;

        }

        //Delete
        public boolean eliminar(int id)
        {
            //escribir
            SQLiteDatabase escritor = this.getWritableDatabase();
            //los paramentros, lo que quiero insertar
            String[] args = new String[] {String.valueOf(id)};

            int respuesta = escritor.delete("lista","id=?",args); // delete lista where id = id);
            escritor.close();

            return respuesta != 0;

//        if(respuesta != -1)
//        {
//            return true;
//        }
//        else
//        {
//            return false;
//        }
        }


        public ArrayList<Lista> buscarTodo()
        {
            ArrayList<Lista> todos = new ArrayList<>();
            //escribir
            SQLiteDatabase escritor = this.getWritableDatabase();
            Cursor cursor = null;
            cursor = escritor.rawQuery("select * from lista",null);
            //pregunto si hay algo al comienzo
            if(cursor.moveToFirst())
            {
                //recorro tupla por tupla
                do{
                    int id = cursor.getInt(0);
                    int run = cursor.getInt(1);
                    String dv = cursor.getString(2);
                    String nombre = cursor.getString(3);
                    String fecha = cursor.getString(4);

                    Lista lista = new Lista(id,run,dv,nombre,fecha);
                    todos.add(lista);

                    //avanzo a la siguiente tupla
                }while (cursor.moveToNext());
            }
            escritor.close();
            return todos;
        }

    }





