package cl.duoc.registroasistencia;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi; // Para usar el now del localDate
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    // Obtener referencia al EditText
    private EditText etFecha;
    // Guardar el último año, mes y día del mes
    private int ultimoAnio, ultimoMes, ultimoDiaDelMes;


    // Crear un listener del datepicker;
    private DatePickerDialog.OnDateSetListener listenerDeDatePicker = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int anio, int mes, int diaDelMes) {
            // Esto se llama cuando seleccionan una fecha. Nos pasa la vista, pero más importante, nos pasa:
            // El año, el mes y el día del mes. Es lo que se necesita para saber la fecha completa

            // Refrescamos las globales
            ultimoAnio = anio;
            ultimoMes = mes;
            ultimoDiaDelMes = diaDelMes;

            // Y refrescamos la fecha
            refrescarFechaEnEditText();

        }
    };

    public void refrescarFechaEnEditText() {
        // Formateamos la fecha pero podríamos hacer cualquier otra cosa ;)
        String fecha = String.format(Locale.getDefault(), "%02d-%02d-%02d", ultimoAnio, ultimoMes + 1, ultimoDiaDelMes);
        // La ponemos en el editText
        etFecha.setText(fecha);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFecha = findViewById(R.id.txtFechaIngreso);
        //Se llama a botonIngresar
        Button btnIngresar = findViewById(R.id.btnIngresar);

        // Poner último año, mes y día a la fecha de hoy
        final Calendar calendario = Calendar.getInstance();
        ultimoAnio = calendario.get(Calendar.YEAR);
        ultimoMes = calendario.get(Calendar.MONTH);
        ultimoDiaDelMes = calendario.get(Calendar.DAY_OF_MONTH);

        // Refrescar la fecha en el EditText
        refrescarFechaEnEditText();

        etFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Le pasamos lo que haya en las globales
                DatePickerDialog dialogoFecha = new DatePickerDialog(MainActivity.this, listenerDeDatePicker, ultimoAnio, ultimoMes, ultimoDiaDelMes);
                // Aquí es cuando dan click así que mostramos el DatePicker
                dialogoFecha.show();
            }
        });

        //se muestra listView con datos de BD
        generarLista();

        //Se configura boton al hacer click
        btnIngresar.setOnClickListener(new View.OnClickListener() {
           // @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View v) {
                EditText txtNombre = findViewById(R.id.txtNombre);
                EditText txtRut = findViewById(R.id.txtRut);
                EditText txtDV = findViewById(R.id.txtVerificador);
                EditText txtFechaIngreso = findViewById(R.id.txtFechaIngreso);

                String msg1 = txtNombre.getText().toString();
                //String msg2 = txtRut.getText().toString();
                int msg2 = Integer.parseInt(txtRut.getText().toString());
                String msg3 = txtDV.getText().toString();
                String msg4 = txtFechaIngreso.getText().toString();

             //Aqui estava el log 1

                if (!msg1.isEmpty()) {
                    Lista lista = new Lista();
                    lista.setNombre(msg1);
                    lista.setRun(msg2);
                    lista.setDv(msg3);
                    lista.setFechaIngreso(msg4);

                    //Aqui estuvo el 2 log

                    CustomSQL sql = new CustomSQL(MainActivity.this, "alien", null, 1);

                    if (sql.insertar(lista)) {
                        generarLista();
                        Toast.makeText(MainActivity.this, "Mensaje guardado", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this, "No se pudo aguardar :(", Toast.LENGTH_LONG).show();
                    }
                } else {
                    txtNombre.setError("Debe ingresar un mensaje");
                }
            }
        });

    }

    private void generarLista ()
    {
        CustomSQL sql = new CustomSQL(MainActivity.this, "alien", null, 1);
        ArrayList<Lista> todos = sql.buscarTodo();
        CustomAdapter adapter = new CustomAdapter(MainActivity.this, R.layout.item_layout, todos);
        ListView lvLista = findViewById(R.id.lvLista);
        lvLista.setAdapter(adapter);
    }
}

//ListView
class CustomAdapter extends ArrayAdapter<Lista> {
    private Context miContexto;
    private int miRecurso;
    private ArrayList<Lista> miLista;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Lista> objects) {
        super(context, resource, objects);
        miContexto = context;
        miRecurso = resource;
        miLista = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);
        View view = LayoutInflater.from(miContexto).inflate(miRecurso, null);
        TextView lblNombre = view.findViewById(R.id.lblNombre);
        TextView lblRut = view.findViewById(R.id.lblRut);
        TextView lblDV = view.findViewById(R.id.lblDv);
        TextView lblFecha = view.findViewById(R.id.lblFecha);
        Button btnEliminar = view.findViewById(R.id.btnEliminar);


        Lista l = miLista.get(position);

        lblNombre.setText(String.valueOf(l.getNombre()));
        lblRut.setText(String.valueOf(l.getRun()));
        lblDV.setText(String.valueOf(l.getDv()));
        lblFecha.setText(String.valueOf(l.getFechaIngreso()));

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(miContexto);
                builder.setTitle("¿Desea Eliminar?");
                builder.setMessage("Eliminado correctamente");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        CustomAdapter.this.remove(l);
                        miLista.remove(l);

                        //Lista lista = new Lista ();
                        CustomSQL sql = new CustomSQL(miContexto, "alien", null, 1);
                        sql.eliminar(l.getId());
                        //sql.eliminar(position);
                    }
                }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        return view;
    }
}

