package cl.duoc.registroasistencia;

import java.time.LocalDate;

public class Lista {

    private int id;
    private int run;
    private String dv;
    private String nombre;
    private String fechaIngreso;

    public Lista(){

    }
    public Lista(int id) {
        this.id = id;
    }

    //Contr con parametros
    public Lista(int run, String dv, String nombre, String fechaIngreso) {
        this.run = run;
        this.dv = dv;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
    }

    public Lista(int id, int run, String dv, String nombre, String fecha) {
    }

    //Getters y Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRun() {
        return run;
    }

    public void setRun(int run) {
        this.run = run;
    }

    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    @Override
    public String toString() {
        return "Lista{" +
                "id=" + id +
                ", run=" + run +
                ", dv='" + dv + '\'' +
                ", nombre='" + nombre + '\'' +
                ", fechaIngreso='" + fechaIngreso + '\'' +
                '}';
    }
}
